## Native Page Transitions Cordova / PhoneGap Plugin
by [Telerik](http://www.telerik.com)


<table width="100%">
    <tr>
        <td width="100"><a href="http://plugins.telerik.com/plugin/native-page-transitions"><img src="http://www.x-services.nl/github-images/telerik-verified-plugins-marketplace.png" width="97px" height="71px" alt="Marketplace logo"/></a></td>
        <td>For a quick demo app and easy code samples, check out the plugin page at the Verified Plugins Marketplace: http://plugins.telerik.com/plugin/native-page-transitions</td>
    </tr>
</table>


[The MIT License (MIT)](http://www.opensource.org/licenses/mit-license.html)
